import pygame
import math
import random

pygame.init()

WIDTH, HEIGHT = 1550, 800
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Sistema Solar")

FONT = pygame.font.SysFont("arial", 16)

class Planet:
    AU = 149.6e6 * 1000 #Distância média entre a Terra e o Sol em metros
    G = 6.67428e-11 #Constante gravitacional universal
    SCALE = 10000 / AU  #Escala para converter distâncias em pixels
    TIMESTEP = 3600 * 24  #Passo de tempo em segundos (equivalente a 1 dia)

    def __init__(self, x, y, radius, mass, name, texture_path, real_radius):
        self.x = x #Posição x do planeta
        self.y = y #Posição y do planeta
        self.radius = radius #Raio do planeta em pixels
        self.mass = mass #Massa do planeta em quilogramas
        self.name = name #Nome do planeta
        self.texture = pygame.image.load(texture_path).convert_alpha() #Textura do planeta
        self.real_radius = real_radius #Raio real do planeta em quilômetros

        self.orbit_color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))  # Cor da órbita

        self.orbit = [] #Lista de pontos que formam a órbita do planeta
        self.sun = False #Indica se o planeta é o Sol
        self.distance_to_sun = 0 #Distância do planeta ao Sol

        self.x_vel = 0 #Velocidade atual do planeta no eixo x
        self.y_vel = 0 #Velocidade atual do planeta no eixo y

        self.zoom = 0.01 #Fator de zoom da visualização
        self.distance_scale = 1 #Escala para exibir distâncias
        self.view_x = 0 #Posição x da visualização
        self.view_y = 0 #Posição y da visualização

    def draw(self, win):
        x = (self.x * self.SCALE * self.zoom) - self.view_x + WIDTH / 2 #Posição x ajustada para a visualização
        y = (self.y * self.SCALE * self.zoom) - self.view_y + HEIGHT / 2 #Posição y ajustada para a visualização
        radius = self.radius * self.zoom #Raio ajustado para a visualização

        if len(self.orbit) > 2:
            updated_points = []
            for point in self.orbit:
                x, y = point
                x = (x * self.SCALE * self.zoom) - self.view_x + WIDTH / 2
                y = (y * self.SCALE * self.zoom) - self.view_y + HEIGHT / 2
                updated_points.append((x, y))

            pygame.draw.lines(win, self.orbit_color, False, updated_points, 2) #Desenha a órbita do planeta



        planet_texture = pygame.transform.scale(self.texture, (int(radius * 2), int(radius * 2))) #Redimensiona a textura do planeta
        planet_rect = planet_texture.get_rect(center=(int(x), int(y)))
        win.blit(planet_texture, planet_rect)  #Desenha a textura do planeta

        if not self.sun:
            scaled_distance = self.distance_to_sun * self.distance_scale
            #distance_text = FONT.render(f"{round(scaled_distance / 1000, 1)}km", 1, (255, 255, 255))
            #win.blit(distance_text, (x - distance_text.get_width() / 2, y - distance_text.get_height() / 2))

        if self.sun:
            sun_name_text = FONT.render("Sun", 1, (255, 255, 255))
            win.blit(sun_name_text, (x - sun_name_text.get_width() / 2, y + self.radius + 5))

    def attraction(self, other):
        other_x, other_y = other.x, other.y
        distance_x = other_x - self.x
        distance_y = other_y - self.y
        distance = math.sqrt(distance_x ** 2 + distance_y ** 2) #Distância entre os planetas

        if other.sun:
            self.distance_to_sun = distance

        force = self.G * self.mass * other.mass / distance ** 2 #Calcula a força gravitacional entre os planetas
        theta = math.atan2(distance_y, distance_x) #Ângulo entre os planetas

        force_x = math.cos(theta) * force #Componente x da força resultante
        force_y = math.sin(theta) * force #Componente y da força resultante
        return force_x, force_y

    def update_position(self, planets, paused):
        if not paused:
            total_fx = total_fy = 0
            for planet in planets:
                if self == planet:
                    continue

                fx, fy = self.attraction(planet) #Calcula a atração entre o planeta atual e os outros planetas
                total_fx += fx
                total_fy += fy

                #Ira manter a velocidade do Sol em 0 m/s apesar deste interagir com os outros planetas
                '''if self.sun:
                    total_fx = 0
                    total_fy = 0'''

            self.x_vel += total_fx / self.mass * self.TIMESTEP #Atualiza a velocidade do planeta no eixo x
            self.y_vel += total_fy / self.mass * self.TIMESTEP #Atualiza a velocidade do planeta no eixo y

            self.x += self.x_vel * self.TIMESTEP #Atualiza a posição do planeta no eixo x
            self.y += self.y_vel * self.TIMESTEP #Atualiza a posição do planeta no eixo y
            self.orbit.append((self.x, self.y)) #Adiciona a posição atual à lista de pontos da órbita


def create_stars(number, w, h):
    stars = []
    for _ in range(number):
        x = random.randint(0, w)
        y = random.randint(0, h)
        stars.append((x, y))
    return stars


def draw_stars(stars, win):
    for star in stars:
        pygame.draw.circle(win, (255, 255, 255), star, 1) #Desenha as estrelas como pontos brancos


def show_planet_info(planet, win, cursor_pos):
    x = (planet.x * planet.SCALE * planet.zoom) - planet.view_x + WIDTH / 2
    y = (planet.y * planet.SCALE * planet.zoom) - planet.view_y + HEIGHT / 2
    radius = planet.radius * planet.zoom

    if x - radius < cursor_pos[0] < x + radius and y - radius < cursor_pos[1] < y + radius:
        info_surface = pygame.Surface((230, 120))
        info_surface.fill((80, 78, 81))
        info_surface.set_alpha(200)
        info_rect = info_surface.get_rect()
        info_rect.center = (x + radius, y - radius)

        info_text1 = FONT.render(f"Planeta: {planet.name}", 1, (255, 255, 255))
        info_text2 = FONT.render(f"Raio: {planet.real_radius} km", 1, (255, 255, 255))
        info_text3 = FONT.render(f"Distância ao Sol: {round(planet.distance_to_sun / 1000, 1)} km", 1, (255, 255, 255))
        info_text4 = FONT.render(f"Velocidade: {round(math.sqrt(planet.x_vel**2 + planet.y_vel**2), 1)} m/s", 1, (255, 255, 255))
        info_text5 = FONT.render(f"Massa: {planet.mass} kg", 1, (255, 255, 255))
        win.blit(info_surface, info_rect)
        win.blit(info_text1, (info_rect.x + 10, info_rect.y + 10))
        win.blit(info_text2, (info_rect.x + 10, info_rect.y + 30))
        win.blit(info_text3, (info_rect.x + 10, info_rect.y + 50))
        win.blit(info_text4, (info_rect.x + 10, info_rect.y + 70))
        win.blit(info_text5, (info_rect.x + 10, info_rect.y + 90))


def main():
    run = True
    clock = pygame.time.Clock()

    sun = Planet(0, 0, 2300, 1.98892 * 10 ** 30, "Sol", "sun.png", 696340)
    sun.sun = True

    earth = Planet(1 * Planet.AU, 0, 1000, 5.9742 * 10 ** 24, "Terra", "earth.png", 6371)
    earth.y_vel = -29.783 * 1000

    mars = Planet(1.524 * Planet.AU, 0, 700, 6.39 * 10 ** 23, "Marte", "mars.png", 3389.5)
    mars.y_vel = -24.077 * 1000

    mercury = Planet(0.387 * Planet.AU, 0, 333, 3.30 * 10 ** 23, "Mercúrio", "mercury.png", 2439.7)
    mercury.y_vel = -47.4 * 1000

    venus = Planet(0.723 * Planet.AU, 0, 700, 4.867 * 10 ** 24, "Vênus", "venus.png", 6051.8)
    venus.y_vel = -35.02 * 1000

    jupiter = Planet(5.203 * Planet.AU, 0, 2000, 1.898 * 10 ** 27, "Júpiter", "jupiter.png", 69911)
    jupiter.y_vel = -13.07 * 1000

    saturn = Planet(9.537 * Planet.AU, 0, 1800, 5.683 * 10 ** 26, "Saturno", "saturn.png", 58232)
    saturn.y_vel = -9.69 * 1000

    uranus = Planet(19.191 * Planet.AU, 0, 1500, 8.681 * 10 ** 25, "Urano", "uranus.png", 25362)
    uranus.y_vel = -6.80 * 1000

    neptune = Planet(30.069 * Planet.AU, 0, 1400, 1.024 * 10 ** 26, "Neptuno", "neptune.png", 24622)
    neptune.y_vel = -5.43 * 1000

    planets = [sun, earth, mars, mercury, venus, jupiter, saturn, uranus, neptune]

    stars = create_stars(100, WIDTH, HEIGHT)

    paused = False

    while run:
        clock.tick(60)
        WIN.fill((0, 0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 4:
                    # Rola o mouse para cima - aumentar o zoom
                    for planet in planets:
                        planet.zoom += 0.001
                elif event.button == 5:
                    # Rola o mouse para baixo - diminuir o zoom
                    for planet in planets:
                        #if planet.zoom > 0.1:
                            planet.zoom -= 0.001
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    paused = not paused

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            for planet in planets:
                planet.view_y -= 20
        if keys[pygame.K_DOWN]:
            for planet in planets:
                planet.view_y += 20
        if keys[pygame.K_LEFT]:
            for planet in planets:
                planet.view_x -= 20
        if keys[pygame.K_RIGHT]:
            for planet in planets:
                planet.view_x += 20

        cursor_pos = pygame.mouse.get_pos()

        for planet in planets:
            planet.update_position(planets, paused)
            planet.draw(WIN)
            show_planet_info(planet, WIN, cursor_pos)

        draw_stars(stars, WIN)

        pygame.display.update()

    pygame.quit()


if __name__ == '__main__':
    main()